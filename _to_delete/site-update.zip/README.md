# FirstOption Exhibition and Events LLC – Website

One-page animated company website built from the *First Option Portfolio 2026*.

## Open it

Double-click `index.html`. No install or build step is needed.
For live reload while editing, open this folder in VS Code and use the **Live Server** extension.

## Folder structure

```
Company_Website/
├── index.html              All page text and sections
├── css/style.css           Brand colours, fonts, layout, animations
├── js/main.js              Typing effect, gallery + photo viewer, map, animated scenes, quote form
├── js/data.js              Lists of stand photos, event photos, client logos and map dots
└── assets/
    ├── brand/              FirstOption logo (white + navy) and the logo mark
    ├── stands/             53 stand photos taken from the portfolio
    ├── events/             16 event photos (CAAF 2023, ATM 2024, ICAO 2025, Emarat Alaman)
    └── clients/            81 client logos
```

## Sections

1. **Hero**: "Your Story. Our Stand." typed on load, company profile card, rotating stand photos
2. **Our values**: mission, values, client promise
3. **What we do**: Exhibitions + Event design & build, with their services
4. **How we work**: animated Design / Build / Deliver scenes
5. **Stands**: photo gallery (photos only, no stand names), tap to view full screen
6. **Events**: event highlights with photos
7. **Clients**: moving logo wall
8. **Network**: animated world map, countries served, shows & venues
9. **Contact**: phones, email, website, location, and a quote form that opens WhatsApp or email

## Common edits

| What | Where |
|---|---|
| Any text | `index.html` |
| Company profile card values | `index.html` → `data-v="..."` |
| Stats (80+, 11, 8+) | `index.html` → `data-count="..."` |
| Colours | `css/style.css` → `:root` (`--accent` orange, `--brand` indigo, `--violet`) |
| Add / remove stand photos | put the .jpg in `assets/stands/` and add or remove it in `js/data.js` → `stands` |
| Add / remove client logos | `assets/clients/` + `js/data.js` → `clients` |
| WhatsApp number for the form and button | `js/main.js` (search `wa.me`) and `index.html` (search `wa.me`) |
| Chat lines in the Deliver animation | `js/main.js` → `const script = [...]` |

## Notes

- Fonts load from Google Fonts. Without internet the page uses system fonts.
- Photos and logos were cut from the portfolio PDF, so the logos are only as sharp as they are there. Replace them with original logo files for a crisper logo wall.
- Visitors with "reduce motion" turned on see the finished state without animation.
